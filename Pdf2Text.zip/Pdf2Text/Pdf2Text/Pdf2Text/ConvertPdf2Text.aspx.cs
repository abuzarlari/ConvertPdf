﻿using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pdf2Text
{
    public partial class ConvertPdf2Text : System.Web.UI.Page
    {
        string fName = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            HttpPostedFile file = HttpContext.Current.Request.Files[0];
            string filename = HttpContext.Current.Server.MapPath("~/SourceFiles/" + flUploadPdf.FileName);
            Session["fName"] = flUploadPdf.FileName;
            file.SaveAs(filename);
        }

        protected void btnCovert_Click(object sender, EventArgs e)
        {
            string SourcePdfPath = HttpContext.Current.Server.MapPath("~/SourceFiles/" + Session["fName"]);
            string outputPath = HttpContext.Current.Server.MapPath("~/DestinationFiles/");
            StringBuilder text = new StringBuilder();
            using (PdfReader reader = new PdfReader(SourcePdfPath))
            {
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    text.AppendLine(PdfTextExtractor.GetTextFromPage(reader, i));
                }
            }
            using (StreamWriter outputFile = new StreamWriter(System.IO.Path.Combine(outputPath, "Pdf2Text.txt")))
            {
                outputFile.WriteLine(text);
            }
        }
    }
}
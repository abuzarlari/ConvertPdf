﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ConvertTxt2Pdf
{
    public partial class ConvertTxt2Pdf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnImport_Click(object sender, EventArgs e)
        {
            HttpPostedFile file = HttpContext.Current.Request.Files[0];
            string sourceFiles = HttpContext.Current.Server.MapPath("~/SourceFiles/"+flupload.FileName);
            file.SaveAs(sourceFiles);
        }

        protected void btnConvert_Click(object sender, EventArgs e)
        {
            string sourceFilePath = HttpContext.Current.Server.MapPath("~/SourceFiles/");
            string[] fileNames = System.IO.Directory.GetFiles(sourceFilePath);
            string fileNameWithoutExt = System.IO.Path.GetFileNameWithoutExtension(fileNames[0]);
            string outputFilePath = HttpContext.Current.Server.MapPath("~/DestFiles/"+fileNameWithoutExt+".pdf");
            StreamReader str = new StreamReader(fileNames[0]);
            Document doc = new Document();
            PdfWriter.GetInstance(doc, new FileStream(outputFilePath, FileMode.Create));
            doc.Open();
            doc.Add(new Paragraph(str.ReadToEnd()));
            doc.Close();
        }
    }
}